// ================================================
// CAR RACING GAME - beginner-friendly game logic
// ================================================

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Page elements
const scoreElement = document.getElementById("score");
const bestScoreElement = document.getElementById("bestScore");
const finalScoreElement = document.getElementById("finalScore");
const overlayBestScoreElement = document.getElementById("overlayBestScore");
const startOverlay = document.getElementById("startOverlay");
const gameOverOverlay = document.getElementById("gameOverOverlay");
const startButton = document.getElementById("startButton");
const restartButton = document.getElementById("restartButton");
const leftButton = document.getElementById("leftButton");
const rightButton = document.getElementById("rightButton");

// The road has three lanes.
const road = {
    x: 55,
    width: 310,
    laneCount: 3
};
const laneWidth = road.width / road.laneCount;

// Player car settings
const player = {
    width: 42,
    height: 76,
    x: 0,
    y: canvas.height - 105,
    speed: 290,
    color: "#ff4d35"
};

// Game state
let enemies = [];
let score = 0;
let bestScore = 0;
let gameRunning = false;
let lastTime = 0;
let enemyTimer = 0;
let roadLineOffset = 0;
let animationId = null;
let keys = { left: false, right: false };

// Load the best score from Flask when the page opens.
async function loadBestScore() {
    try {
        const response = await fetch("/api/best-score");
        const data = await response.json();
        bestScore = data.best_score || 0;
        showBestScore();
    } catch (error) {
        console.log("Could not load best score. The game can still be played.");
    }
}

function showBestScore() {
    bestScoreElement.textContent = String(bestScore).padStart(4, "0");
    overlayBestScoreElement.textContent = bestScore;
}

// Keep the player in the middle lane when a new game starts.
function resetGame() {
    score = 0;
    enemies = [];
    enemyTimer = 0;
    roadLineOffset = 0;
    player.x = road.x + laneWidth + (laneWidth - player.width) / 2;
    player.y = canvas.height - 105;
    scoreElement.textContent = "0000";
    keys.left = false;
    keys.right = false;
}

// Start or restart the race.
function startGame() {
    if (animationId) {
        cancelAnimationFrame(animationId);
    }

    resetGame();
    gameRunning = true;
    startOverlay.classList.add("hidden");
    gameOverOverlay.classList.add("hidden");
    lastTime = performance.now();
    animationId = requestAnimationFrame(gameLoop);
}

// Draw a simple car using canvas shapes. No image files are required.
function drawCar(x, y, width, height, color, isPlayer = false) {
    // Wheels
    ctx.fillStyle = "#090d12";
    ctx.fillRect(x - 4, y + 12, 6, 18);
    ctx.fillRect(x + width - 2, y + 12, 6, 18);
    ctx.fillRect(x - 4, y + height - 30, 6, 18);
    ctx.fillRect(x + width - 2, y + height - 30, 6, 18);

    // Main body
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, 9);
    ctx.fill();

    // Front / windshield
    ctx.fillStyle = isPlayer ? "#b9e9f5" : "#d4e3e9";
    ctx.beginPath();
    ctx.roundRect(x + 7, y + 13, width - 14, 20, 5);
    ctx.fill();

    // Rear window
    ctx.fillStyle = "rgba(15, 25, 33, 0.8)";
    ctx.beginPath();
    ctx.roundRect(x + 8, y + height - 25, width - 16, 13, 3);
    ctx.fill();

    // Headlights and tail lights
    ctx.fillStyle = isPlayer ? "#fff3b0" : "#ff6262";
    ctx.fillRect(x + 5, isPlayer ? y + 2 : y + height - 5, 8, 4);
    ctx.fillRect(x + width - 13, isPlayer ? y + 2 : y + height - 5, 8, 4);
}

// Draw the one straight road and moving dashed lane markings.
function drawRoad(deltaTime) {
    ctx.fillStyle = "#263b2d";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#292f35";
    ctx.fillRect(road.x, 0, road.width, canvas.height);

    // Road edges
    ctx.fillStyle = "#e5e5e5";
    ctx.fillRect(road.x, 0, 5, canvas.height);
    ctx.fillRect(road.x + road.width - 5, 0, 5, canvas.height);

    // Dashed lane lines
    roadLineOffset += getCurrentSpeed() * deltaTime;
    if (roadLineOffset > 60) roadLineOffset = 0;

    ctx.fillStyle = "rgba(255,255,255,0.75)";
    for (let lane = 1; lane < road.laneCount; lane++) {
        const lineX = road.x + lane * laneWidth - 2;
        for (let y = -60 + roadLineOffset; y < canvas.height; y += 60) {
            ctx.fillRect(lineX, y, 4, 32);
        }
    }
}

// Speed increases slowly as the score increases.
function getCurrentSpeed() {
    return Math.min(260 + score * 2.2, 650);
}

// Create an enemy car in a random lane.
function createEnemy() {
    const lane = Math.floor(Math.random() * road.laneCount);
    const enemyWidth = 42;
    const enemyHeight = 76;
    const x = road.x + lane * laneWidth + (laneWidth - enemyWidth) / 2;

    const colors = ["#f5b942", "#368ed1", "#9b72cf", "#e6e9ed"];
    const color = colors[Math.floor(Math.random() * colors.length)];

    enemies.push({
        x: x,
        y: -enemyHeight,
        width: enemyWidth,
        height: enemyHeight,
        color: color,
        passed: false
    });
}

// Basic rectangle collision check.
// If the two rectangles overlap, the cars have crashed.
function checkCollision(carA, carB) {
    const padding = 7; // A small padding makes the collision feel fair.
    return (
        carA.x + padding < carB.x + carB.width - padding &&
        carA.x + carA.width - padding > carB.x + padding &&
        carA.y + padding < carB.y + carB.height - padding &&
        carA.y + carA.height - padding > carB.y + padding
    );
}

// Update the player's position from keyboard or touch input.
function movePlayer(deltaTime) {
    if (keys.left) {
        player.x -= player.speed * deltaTime;
    }
    if (keys.right) {
        player.x += player.speed * deltaTime;
    }

    // Do not allow the car to leave the road.
    const minX = road.x + 9;
    const maxX = road.x + road.width - player.width - 9;
    player.x = Math.max(minX, Math.min(maxX, player.x));
}

// Update enemy positions, score and collisions.
function updateGame(deltaTime) {
    movePlayer(deltaTime);

    const currentSpeed = getCurrentSpeed();
    enemyTimer += deltaTime;

    // Spawn cars more often as the game becomes faster.
    const spawnDelay = Math.max(0.58, 1.25 - score * 0.003);
    if (enemyTimer >= spawnDelay) {
        createEnemy();
        enemyTimer = 0;
    }

    for (let i = enemies.length - 1; i >= 0; i--) {
        const enemy = enemies[i];
        enemy.y += currentSpeed * deltaTime;

        // IMPORTANT: collision ends the game immediately.
        if (checkCollision(player, enemy)) {
            endGame();
            return;
        }

        // Give one point when an enemy car has passed the player.
        if (!enemy.passed && enemy.y > player.y + player.height) {
            enemy.passed = true;
            score += 10;
            scoreElement.textContent = String(score).padStart(4, "0");
        }

        // Remove enemy cars after they leave the bottom of the road.
        if (enemy.y > canvas.height + enemy.height) {
            enemies.splice(i, 1);
        }
    }
}

// Draw the player and every enemy car.
function drawGame(deltaTime = 0) {
    drawRoad(deltaTime);
    enemies.forEach(enemy => {
        drawCar(enemy.x, enemy.y, enemy.width, enemy.height, enemy.color);
    });
    drawCar(player.x, player.y, player.width, player.height, player.color, true);
}

// The main game loop runs many times per second.
function gameLoop(currentTime) {
    if (!gameRunning) return;

    // deltaTime keeps movement consistent on different computers.
    const deltaTime = Math.min((currentTime - lastTime) / 1000, 0.05);
    lastTime = currentTime;

    updateGame(deltaTime);
    drawGame(deltaTime);

    if (gameRunning) {
        animationId = requestAnimationFrame(gameLoop);
    }
}

// Stop the game and show the final result.
async function endGame() {
    if (!gameRunning) return;

    gameRunning = false;
    finalScoreElement.textContent = score;

    if (score > bestScore) {
        bestScore = score;
        showBestScore();
        await saveBestScore(score);
    }

    overlayBestScoreElement.textContent = bestScore;
    gameOverOverlay.classList.remove("hidden");
}

async function saveBestScore(newScore) {
    try {
        const response = await fetch("/api/best-score", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ score: newScore })
        });
        const data = await response.json();
        bestScore = data.best_score || bestScore;
        showBestScore();
    } catch (error) {
        console.log("Could not save the best score. Check the Flask server.");
    }
}

// Keyboard controls: arrows or A / D.
document.addEventListener("keydown", event => {
    const key = event.key.toLowerCase();

    if (["arrowleft", "arrowright", "a", "d", " "].includes(key)) {
        event.preventDefault();
    }

    if (key === "arrowleft" || key === "a") keys.left = true;
    if (key === "arrowright" || key === "d") keys.right = true;
});

document.addEventListener("keyup", event => {
    const key = event.key.toLowerCase();
    if (key === "arrowleft" || key === "a") keys.left = false;
    if (key === "arrowright" || key === "d") keys.right = false;
});

// Mobile touch buttons. Pointer events support touch, mouse and stylus.
function holdButton(button, direction) {
    button.addEventListener("pointerdown", event => {
        event.preventDefault();
        keys[direction] = true;
        button.setPointerCapture(event.pointerId);
    });

    const stopMoving = () => { keys[direction] = false; };
    button.addEventListener("pointerup", stopMoving);
    button.addEventListener("pointercancel", stopMoving);
    button.addEventListener("lostpointercapture", stopMoving);
}

holdButton(leftButton, "left");
holdButton(rightButton, "right");

startButton.addEventListener("click", startGame);
restartButton.addEventListener("click", startGame);

// Draw the road before the first game starts.
resetGame();
drawGame();
loadBestScore();
