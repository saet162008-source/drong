from pathlib import Path

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
BEST_SCORE_FILE = Path(__file__).with_name("best_score.txt")


def read_best_score():
    """Read the saved best score, returning zero when no score exists yet."""
    try:
        return max(0, int(BEST_SCORE_FILE.read_text(encoding="utf-8").strip()))
    except (OSError, ValueError):
        return 0


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/best-score")
def get_best_score():
    return jsonify({"best_score": read_best_score()})


@app.post("/api/best-score")
def save_best_score():
    data = request.get_json(silent=True) or {}
    try:
        new_score = max(0, int(data.get("score", 0)))
    except (TypeError, ValueError):
        return jsonify({"error": "score must be a number"}), 400

    best_score = max(read_best_score(), new_score)
    try:
        BEST_SCORE_FILE.write_text(str(best_score), encoding="utf-8")
    except OSError:
        app.logger.exception("Could not save the best score.")
        return jsonify({"error": "best score could not be saved"}), 500
    return jsonify({"best_score": best_score})


if __name__ == "__main__":
    app.run(debug=True)
