const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scoreElement = document.getElementById("score");
const bestScoreElement = document.getElementById("bestScore");
const finalScoreElement = document.getElementById("finalScore");
const overlayBestScoreElement = document.getElementById("overlayBestScore");
const gameStatus = document.getElementById("gameStatus");
const startOverlay = document.getElementById("startOverlay");
const gameOverOverlay = document.getElementById("gameOverOverlay");
const player = { width: 42, height: 76, x: 0, y: canvas.height - 105, speed: 290, color: "#f04e3e" };
const road = { x: 55, width: 310, laneCount: 3 };
const laneWidth = road.width / road.laneCount;
let enemies = [], score = 0, bestScore = 0, gameRunning = false, lastTime = 0;
let enemyTimer = 0, roadLineOffset = 0, animationId = null, keys = { left: false, right: false };

async function loadBestScore() {
    try {
        const response = await fetch("/api/best-score");
        const data = await response.json();
        bestScore = data.best_score || 0;
        showBestScore();
    } catch (error) { console.warn("Best score could not be loaded.", error); }
}
function showBestScore() {
    bestScoreElement.textContent = String(bestScore).padStart(4, "0");
    overlayBestScoreElement.textContent = bestScore;
}
function resetGame() {
    score = 0; enemies = []; enemyTimer = 0; roadLineOffset = 0;
    player.x = road.x + laneWidth + (laneWidth - player.width) / 2;
    player.y = canvas.height - 105; scoreElement.textContent = "0000";
    keys.left = false; keys.right = false;
}
function startGame() {
    if (animationId) cancelAnimationFrame(animationId);
    resetGame(); gameRunning = true; gameStatus.textContent = "RACING";
    startOverlay.classList.add("hidden"); gameOverOverlay.classList.add("hidden");
    lastTime = performance.now(); animationId = requestAnimationFrame(gameLoop);
}
function drawCar(x, y, width, height, color, isPlayer = false) {
    ctx.fillStyle = "#090d12";
    ctx.fillRect(x - 4, y + 12, 6, 18); ctx.fillRect(x + width - 2, y + 12, 6, 18);
    ctx.fillRect(x - 4, y + height - 30, 6, 18); ctx.fillRect(x + width - 2, y + height - 30, 6, 18);
    ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x, y, width, height, 9); ctx.fill();
    ctx.fillStyle = isPlayer ? "#b9e9f5" : "#d4e3e9"; ctx.beginPath();
    ctx.roundRect(x + 7, y + 13, width - 14, 20, 5); ctx.fill();
    ctx.fillStyle = "rgba(15, 25, 33, .8)"; ctx.beginPath();
    ctx.roundRect(x + 8, y + height - 25, width - 16, 13, 3); ctx.fill();
    ctx.fillStyle = isPlayer ? "#fff3b0" : "#ff6262";
    ctx.fillRect(x + 5, isPlayer ? y + 2 : y + height - 5, 8, 4);
    ctx.fillRect(x + width - 13, isPlayer ? y + 2 : y + height - 5, 8, 4);
}
function getCurrentSpeed() { return Math.min(260 + score * 2.2, 650); }
function drawRoad(deltaTime) {
    ctx.fillStyle = "#263b2d"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#292f35"; ctx.fillRect(road.x, 0, road.width, canvas.height);
    ctx.fillStyle = "#e5e5e5"; ctx.fillRect(road.x, 0, 5, canvas.height);
    ctx.fillRect(road.x + road.width - 5, 0, 5, canvas.height);
    roadLineOffset = (roadLineOffset + getCurrentSpeed() * deltaTime) % 60;
    ctx.fillStyle = "rgba(255,255,255,.75)";
    for (let lane = 1; lane < road.laneCount; lane++) {
        const lineX = road.x + lane * laneWidth - 2;
        for (let y = -60 + roadLineOffset; y < canvas.height; y += 60) ctx.fillRect(lineX, y, 4, 32);
    }
}
function createEnemy() {
    const lane = Math.floor(Math.random() * road.laneCount), width = 42, height = 76;
    const colors = ["#f5b942", "#368ed1", "#9b72cf", "#e6e9ed"];
    enemies.push({ x: road.x + lane * laneWidth + (laneWidth - width) / 2, y: -height, width, height, color: colors[Math.floor(Math.random() * colors.length)], passed: false });
}
function checkCollision(a, b) {
    const padding = 7;
    return a.x + padding < b.x + b.width - padding && a.x + a.width - padding > b.x + padding &&
        a.y + padding < b.y + b.height - padding && a.y + a.height - padding > b.y + padding;
}
function updateGame(deltaTime) {
    if (keys.left) player.x -= player.speed * deltaTime;
    if (keys.right) player.x += player.speed * deltaTime;
    player.x = Math.max(road.x + 9, Math.min(road.x + road.width - player.width - 9, player.x));
    enemyTimer += deltaTime;
    if (enemyTimer >= Math.max(.58, 1.25 - score * .003)) { createEnemy(); enemyTimer = 0; }
    for (let i = enemies.length - 1; i >= 0; i--) {
        const enemy = enemies[i]; enemy.y += getCurrentSpeed() * deltaTime;
        if (checkCollision(player, enemy)) { endGame(); return; }
        if (!enemy.passed && enemy.y > player.y + player.height) {
            enemy.passed = true; score += 10; scoreElement.textContent = String(score).padStart(4, "0");
        }
        if (enemy.y > canvas.height + enemy.height) enemies.splice(i, 1);
    }
}
function drawGame(deltaTime = 0) {
    drawRoad(deltaTime); enemies.forEach(enemy => drawCar(enemy.x, enemy.y, enemy.width, enemy.height, enemy.color));
    drawCar(player.x, player.y, player.width, player.height, player.color, true);
}
function gameLoop(currentTime) {
    if (!gameRunning) return;
    const deltaTime = Math.min((currentTime - lastTime) / 1000, .05); lastTime = currentTime;
    updateGame(deltaTime); drawGame(deltaTime);
    if (gameRunning) animationId = requestAnimationFrame(gameLoop);
}
async function endGame() {
    if (!gameRunning) return;
    gameRunning = false; gameStatus.textContent = "CRASHED"; finalScoreElement.textContent = score;
    if (score > bestScore) { bestScore = score; showBestScore(); await saveBestScore(score); }
    gameOverOverlay.classList.remove("hidden");
}
async function saveBestScore(newScore) {
    try {
        const response = await fetch("/api/best-score", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ score: newScore }) });
        const data = await response.json(); bestScore = data.best_score || bestScore; showBestScore();
    } catch (error) { console.warn("Best score could not be saved.", error); }
}
document.addEventListener("keydown", event => {
    const key = event.key.toLowerCase();
    if (["arrowleft", "arrowright", "a", "d"].includes(key)) event.preventDefault();
    if (key === "arrowleft" || key === "a") keys.left = true;
    if (key === "arrowright" || key === "d") keys.right = true;
});
document.addEventListener("keyup", event => {
    const key = event.key.toLowerCase();
    if (key === "arrowleft" || key === "a") keys.left = false;
    if (key === "arrowright" || key === "d") keys.right = false;
});
function holdButton(button, direction) {
    const stop = () => { keys[direction] = false; };
    button.addEventListener("pointerdown", event => { event.preventDefault(); keys[direction] = true; button.setPointerCapture(event.pointerId); });
    button.addEventListener("pointerup", stop); button.addEventListener("pointercancel", stop); button.addEventListener("lostpointercapture", stop);
}
holdButton(document.getElementById("leftButton"), "left");
holdButton(document.getElementById("rightButton"), "right");
document.getElementById("startButton").addEventListener("click", startGame);
document.getElementById("restartButton").addEventListener("click", startGame);
resetGame(); drawGame(); loadBestScore();
